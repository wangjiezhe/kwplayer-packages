# Copyright (C) 2013-2014 LiuLang <gsushzhsosgsu@gmail.com>
# Use of this source code is governed by GPLv3 license that can be found
# in the LICENSE file.

# kuwo python lib placeholder

__version__ = '3.4.6'
__doc__ = 'Music player for Linux users'
