# Copyright (C) 2013-2014 LiuLang <gsushzhsosgsu@gmail.com>
# Use of this source code is governed by GPLv3 license that can be found
# in the LICENSE file.

# kuwo python lib placeholder

__version__ = '3.4.3'
__doc__ = '''KW music player is used to get music resources from Internet.
It can also play MV, show lyrics and show photo albums of artists.
'''
